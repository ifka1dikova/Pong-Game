/* LEVEL #2 PONG GAME * IVELINA KOSMOVA * */


const BALL_SPEED =7;
const BALL_RADIUS=20;
var paddle1;
var paddle2;
var paddle1V; 
var paddle2V;

var paddle1Score;
var paddle2Score;
var soundWall;     // sound when hitting the wall
var soundPaddle;   // sound when interacting with the paddle
//var soundMiss;
var song;          // background sound



var ball, ballV;

function preload(){
    soundWall = loadSound("sounds/pong_hit_wall.ogg");
    soundPaddle = loadSound("sounds/pong_hit_paddle.ogg");
    soundMiss = loadSound("sounds/pong_miss_ball.ogg");
	song = loadSound("sounds/song.mp3")
    }

function setup() {
  createCanvas(600,400);
  paddle1=paddle2= height/2-50;
  paddle1V= paddle2V=0;
  paddle1Score= paddle2Score=0;
    song.play();   // playing the background sound once
	
	ball= createVector(width/2, height/2);
	
	ballV= createVector(random(-1,1), random(-1,1)); // giving the ball a random trajectory
    //ballV.mult(random(1,1.1) );
    ballV.setMag(BALL_SPEED);
    
    textAlign(CENTER);
    textSize(30);
    fill(255);
	
}

 function draw() {
  background(24,186,33);
	line(width/2 ,1,width/2,3000);
   stroke(255);
  	line(1, 67, 600 , 67); // 1st line 1/3 of the court  top
	line(1, 333, 600 , 333); //2nd line 1/3 of the court  down 
	line(110, 200, 490 ,200); // middle line 
	line(110, 67, 110 ,333);  //  left rectangle 
	line(490, 67, 490 ,333);  // right rectangle
	
	
	
	/* draw paddles*/
	
  rect(20, paddle1,10,100); /*  draw the left paddle */
	
  rect(width-30, paddle2,10,100);  /*  draw the right paddle */
	/* draw ball */
	ellipse(ball.x, ball.y,BALL_RADIUS);
	
    
    /*  draw scoreboard */
	
	text (paddle1Score + " | " + paddle2Score, width /2 ,50);
	/* handle paddles*/
	
	handlePaddles();
	handleBall();
}
	
	function handleBall(){
			
	ball.x+= ballV.x;
	ball.y+= ballV.y;
        
        
		/* top & bottom collisions */
		if (ball.y> height || ball.y< 0)
			ballV.y*= -1;  // reverse 
  
        
		/* paddle collisions */
		if (ball.x <=30 ){  
            
            
            // out of bounds
            
            if( ball.x <=10){
				soundWall.play(); // play the sound when the ball hit the wall
                paddle2Score++;
                reset();
                return;
                
            }
                // right paddle
			 if (ball.y> paddle1 && ball.y <paddle1 +100 ) {
                 if (ballV.x<0){  // prevent the ball getting stuck 
				 soundPaddle.play();   // play the sound if the paddle touch the ball
				 ballV.x*=-1;
			ballV.mult(random(1,1.1));
             }
				}
        
        } else if (ball.x >= width-30){  
                    
                    //out of bounds
                     if (ball.x >= width-10){
						 soundWall.play(); // play the sound when the ball hit the wall
                         paddle1Score ++;
                         reset();
                         return;
                         
                         //left paddle
                     }
					 if (ball.y> paddle2 && ball.y <paddle2 +100 ) {
                         if (ballV.x> 0){ // prevent the ball from getting stuck inside paddle
                       soundPaddle.play(); // play the sound if the paddle touchs the ball
					   ballV.x*=-1;  
                         ballV.mult(random(1,1.1));
                     }
	           }
           }

         }
function reset(){
    
    ballV.setMag(BALL_SPEED)
    ball= createVector( width/2, height/2 );  // located in the center
    
}


function handlePaddles() {
	/* player one controls*/
	 if (keyIsDown(87)){
		 /* move up */
		 paddle1V-=5;
		 
	 }
	
	else if (keyIsDown(83)){
		/*move down*/
		paddle1V+=5;
	}
	
	/* player two controls*/
	 if (keyIsDown(UP_ARROW)){
		 /*move up */
		 paddle2V-=5;
		 
	 }
	
	else if (keyIsDown(DOWN_ARROW)){
		/*move down*/
		paddle2V+=5;
	}
    
     /*  change position */ 
	
	paddle1+=paddle1V;
	paddle2+= paddle2V;
	
	/* friction*/
	paddle1V*=0.4;
	paddle2V*=0.4;
	
	
	/* constrain paddles*/
	paddle1= constrain( paddle1,0, height-100);
	paddle2= constrain( paddle2,0, height-100);
}


/* LEVEL 2 
 appearance : tennis court 
 
 */
 
 
 
 
 
 
 